<template>
  <img 
    :src="src"
    :alt="alt"
    :class="['img-fluid', sizeClass]"
    :style="customStyle"
  />
</template>

<script setup>
defineProps({
  src: {
    type: String,
    required: true
  },
  alt: {
    type: String,
    default: 'Image'
  },
  aspectRatio: {
    type: String,
    default: 'auto',
    validator: (v) => ['auto', '1:1', '16:9', '4:3', '3:2'].includes(v)
  },
  customStyle: {
    type: Object,
    default: () => ({})
  }
})

const sizeClass = computed(() => {
  return {
    '1:1': 'ratio-1x1',
    '16:9': 'ratio-16x9',
    '4:3': 'ratio-4x3',
    '3:2': 'ratio-3x2'
  }[aspectRatio] || ''
})

import { computed } from 'vue'
</script>

<style scoped>
.img-fluid {
  max-width: 100%;
  height: auto;
  border-radius: 6px;
}

.ratio-1x1 {
  aspect-ratio: 1 / 1;
  object-fit: cover;
}

.ratio-16x9 {
  aspect-ratio: 16 / 9;
  object-fit: cover;
}

.ratio-4x3 {
  aspect-ratio: 4 / 3;
  object-fit: cover;
}

.ratio-3x2 {
  aspect-ratio: 3 / 2;
  object-fit: cover;
}
</style>
